package com.practice.a18321519_142;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
 ListView listing;
 Button regbtn;
 int selectedindex=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       listing= (ListView) findViewById(R.id.listing);
       regbtn=(Button) findViewById(R.id.regbtn);

        String list[] = {"Computer Science", "Software Engineering", "Business Education", "Zology", "Botany"};


        ArrayAdapter eventAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, list);
        listing.setAdapter(eventAdapter);


        listing.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                view.setBackgroundColor(getColor(R.color.purple_500 )) ;
                selectedindex=position;
            }
        });
              regbtn.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {
                      Toast.makeText(MainActivity.this,"Registered successfully ",Toast.LENGTH_LONG).show();
                      Intent i= new Intent(MainActivity.this,MainActivity2.class);
                       String value=list[selectedindex];
                       i.putExtra("send",value);
                       startActivity(i);

                  }
              });
    }

    }


