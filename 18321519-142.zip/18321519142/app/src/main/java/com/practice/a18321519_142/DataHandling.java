package com.practice.a18321519_142;

public class DataHandling {
    String name;
    String father;
    String contact;
    String email;
    String age;

    public DataHandling(String name, String father, String contact, String email, String age) {
        this.name = name;
        this.father = father;
        this.contact = contact;
        this.email = email;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFather() {
        return father;
    }

    public void setFather(String father) {
        this.father = father;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }
}
