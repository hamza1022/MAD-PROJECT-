package com.practice.a18321519_142;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;

import java.util.ArrayList;

public class Fetchdata extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<DataHandling> dataholder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fetchdata);

        recyclerView = (RecyclerView) findViewById(R.id.recview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Cursor cursor = new DBHelper(this).readalldata();
        dataholder = new ArrayList<>();

        while (cursor.moveToNext()) {
            DataHandling obj = new DataHandling(cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5));
            dataholder.add(obj);
        }

        Myadapter adapter = new Myadapter(dataholder);
        recyclerView.setAdapter(adapter);

    }
}
