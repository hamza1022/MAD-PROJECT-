package com.practice.a18321519_142;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Myadapter  extends RecyclerView.Adapter<Myadapter.myviewholder> {
    ArrayList<DataHandling> dataholder;

    public Myadapter(ArrayList<DataHandling> dataholder) {
        this.dataholder = dataholder;
    }


    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlelist,parent,false);
        return new myviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myviewholder holder, int position) {
        holder.dname.setText(dataholder.get(position).getName());
        holder.dcontact.setText(dataholder.get(position).getContact());
        holder.dfather.setText(dataholder.get(position).getFather());
        holder.dage.setText(dataholder.get(position).getAge());
        holder.demail.setText(dataholder.get(position).getEmail());



    }

    @Override
    public int getItemCount() {
        return dataholder.size();
    }

    public class myviewholder extends RecyclerView.ViewHolder {
        TextView dname,dfather,dcontact,demail,dage;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            dname=(TextView)itemView.findViewById(R.id.displayname);
            dfather=(TextView)itemView.findViewById(R.id.displayfather);
            dcontact=(TextView)itemView.findViewById(R.id.displaycontact);
            demail=(TextView)itemView.findViewById(R.id.displayemail);
            dage=(TextView)itemView.findViewById(R.id.displayage);


        }
    }
}
