package com.practice.a18321519_142;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity2 extends AppCompatActivity {
TextView show;
String rec="";
EditText name,father,contact,email,age;
Button formbtn,delbtn;
     FloatingActionButton fbtn;
@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    show= findViewById(R.id.pname);
    name= findViewById(R.id.name);
    father= findViewById(R.id.father);
    contact= findViewById(R.id.contact);
    email= findViewById(R.id.email);
    age= findViewById(R.id.age);
    formbtn=findViewById(R.id.formbtn);
    fbtn=findViewById(R.id.fbtn);
    delbtn=findViewById(R.id.delbtn);

    rec=getIntent().getStringExtra("send");
    show.setText(rec);

   formbtn.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {

           processinsert(name.getText().toString(),father.getText().toString(),contact.getText().toString(),email.getText().toString(),age.getText().toString());


       }
   });
delbtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        int z=1;
        int i = new DBHelper(MainActivity2.this).deleteuserList(z);
    }
});


   fbtn.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
           startActivity(new Intent(getApplicationContext(),Fetchdata.class));
       }
   });

    }

    private void processinsert(String n, String f, String c, String e, String a)
    {
        String res=new DBHelper(this).addrecord(n,f,c,e,a);
        name.setText("");
        contact.setText("");
        father.setText("");
        email.setText("");
        age.setText("");
        Toast.makeText(getApplicationContext(),res,Toast.LENGTH_SHORT).show();
    }
}